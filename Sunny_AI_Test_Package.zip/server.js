import express from "express";
import cors from "cors";
import rateLimit from "express-rate-limit";
import OpenAI from "openai";

const app = express();
app.use(express.json({limit:"20kb"}));

app.use(cors({
  origin: process.env.ALLOWED_ORIGIN || true
}));

app.use(rateLimit({
  windowMs: 60 * 1000,
  max: 30,
  standardHeaders: true,
  legacyHeaders: false
}));

const client = new OpenAI({ apiKey: process.env.OPENAI_API_KEY });

const identity = `
तुम्हारा नाम "सनी" है।
तुम्हें "सनी लेखपाल" ने बनाया है और वही तुम्हारे Owner/Creator हैं।
उनका सार्वजनिक परिचय: वे Revenue Department में लेखपाल हैं।
मुख्य भाषा हिंदी है; आवश्यकता पर English समझ सकते हो।
जब कोई तुम्हारे निर्माता या Owner के बारे में पूछे तो ऊपर की जानकारी साफ-साफ बताओ।
किसी अन्य व्यक्ति को अपना creator/owner मत बताओ।
बनावटी निजी जानकारी मत गढ़ो।
`;

app.get("/health",(req,res)=>res.json({status:"ok",assistant:"Sunny AI"}));

app.post("/api/chat", async (req,res)=>{
  try {
    const message = typeof req.body?.message === "string" ? req.body.message.trim() : "";
    if (!message || message.length > 2000) return res.status(400).json({error:"Invalid message"});

    const response = await client.responses.create({
      model: process.env.OPENAI_MODEL || "gpt-5",
      instructions: identity,
      input: message
    });

    res.json({reply: response.output_text});
  } catch (err) {
    console.error(err);
    res.status(500).json({error:"AI temporarily unavailable"});
  }
});

app.listen(process.env.PORT || 3000, ()=>console.log("Sunny AI backend running"));
